Hello, thanks for downloading.
I hope you like my arrangements!

===========================

[ENGLISH]
Terms of Use:
## YouTube
- You are allowed to use my instrumental on your cover or videos.
- YouTube ads monetization is allowed.
- Credit to my YouTube channel http://www.youtube.com/user/FarPras is required.
- You are not allowed to sell the cover without my permission.
- You are not allowed to redistribute the instrumental track.

## Commercial
- Commercial license is USD 40,00 and send through Paypal (http://paypal.me/farpras28).
- Once you've paid the license, you can sell your cover with my arrangement without any royalty.
- No credit link is required.
- Please contact me by email (farpras28@outlook.com) first, before making the payment and further information.
- Distributing the instrumental track only is not allowed.

===========================

Find me:
http://twitter.com/farpras
http://instagram.com/farpras
http://youtube.com/farpras